import React from 'react'
import Grid from '@mui/material/Grid';
import Box from '@mui/material/Box';
import { useNavigate } from "react-router-dom";
//COMPONENTES
import imgPortada from '../../../src/assets/home/portada.png'
import imgUser from '../../../src/assets/header/user.png'
import { Fab, Tooltip, Typography } from '@mui/material';
import SearchIcon from '@mui/icons-material/Search';
import Inventory2OutlinedIcon from '@mui/icons-material/Inventory2Outlined';
const Home = ({ setDataPedido, dataPedido, inicioSesion }) => {

  let navigate = useNavigate();

  const handleClick = () => {
    navigate('/loQueSea')
  }
  return (
    <div>
      <Box sx={{ width: '100%', pt: 4 }}>
        <Grid container direction="row" justifyContent={'center'} rowSpacing={1} columnSpacing={1}>
          <Grid item xs={6} container justifyContent={'center'}>
            <Grid item xs={12}>
              <Typography
                mt={4}
                ml={20}
                style={{ fontWeight: 'bold', fontSize: '65px', color: '#232229', fontFamily: 'Bitter, ExtraBold', lineHeight: 1 }}
              >
                Vos <span style={{ color: '#F15F37' }}>elegís,</span> nosotros te lo <span style={{ color: '#F15F37' }}>llevamos</span>
              </Typography>
            </Grid>
            <Grid item xs={1} pb={4}>
              <Typography
                ml={20}
              >
                <img src={imgUser} alt={'imagen usuario'} style={{ width: '40px' }} />

              </Typography>
            </Grid>
            <Grid item xs={11} pb={4}>
              <Typography
                ml={20}
                mr={15}
                style={{ fontSize: '20px', color: '#232229', fontFamily: 'Bitter, ExtraBold', lineHeight: 1 }}
              >
                Pedí lo que quieras desde tu casa, nosotros lo llevamos
              </Typography>
            </Grid>
            <Grid item >
              <Tooltip title={inicioSesion ? '' : 'Inicié sesion para utilizar esta funcionalidad'} >
                <div>
                  <Fab disabled={inicioSesion ? false : true} variant="extended" size="large" style={{ backgroundColor: '#4C966D', color: '#FFFFFF', fontSize: '10px' }}>
                    <SearchIcon fontSize='small' sx={{ mr: 2, borderRight: '1px solid #FFFFFF', color: '#FFFFFF' }} />
                    Buscar restaurantes
                  </Fab>
                </div>
              </Tooltip>
            </Grid>
            <Grid item ml={2} >
              <Tooltip title={inicioSesion ? '' : 'Inicié sesion para utilizar esta funcionalidad'}>
                <div>
                  <Fab disabled={inicioSesion ? false : true} variant="extended" size="large" style={{ backgroundColor: '#F15F37', color: '#FFFFFF', fontSize: '10px' }} onClick={handleClick}>
                    <Inventory2OutlinedIcon fontSize='small' sx={{ mr: 2, borderRight: '1px solid #FFFFFF', color: '#FFFFFF' }} />
                    Pedir lo que sea
                  </Fab>
                </div>
              </Tooltip>
            </Grid>
          </Grid>
          <Grid item xs={6} >
            <img alt='imagen portada' src={imgPortada} />
          </Grid>
        </Grid>
      </Box>
    </div>
  )
}

export default Home