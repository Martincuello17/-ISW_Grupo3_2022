import React from 'react'

const ButtonAction = ({size, color, titulo }) => {
  return (
      <Fab variant="extended" size="medium" color="primary" aria-label="add">
        <NavigationIcon sx={{ mr: 1 }} />
          Extended
      </Fab>
  )
}

export default ButtonAction