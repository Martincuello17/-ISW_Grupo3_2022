import React, { useState } from 'react'

import { styled } from '@mui/material/styles';
import Button from '@mui/material/Button';
import { Typography } from '@mui/material';

const Input = styled('input')({
  display: 'none',
});


const UpdateFile = ({ setPesoArchivo, pesoArchivo }) => {
  const [file, setFile] = useState(null)
  const [error, setError] = useState('')

  const handleFiles = (e) => {
    const file = e.target.files[0]
    if (file) {
      let type = file?.type.split('/')[1];
      if (type === 'jpg' || type === 'jpeg') {
        let size = (file.size / 1000000).toFixed(2);
        if (size <= 5) {
          setError('')
          setFile(file)
          setPesoArchivo(parseInt((file.size / 1000000).toFixed(2)))
        }
        else {
          setFile(null)
          setPesoArchivo(null)
          setError('Solo archivos minimos a 5 MB')
        }
      }
      else {
        setFile(null)
        setPesoArchivo(null)
        setError('Solo archivos JPG')
      }
    } else {
      setFile(null)
    }

  }

  return (
    <label htmlFor="contained-button-file">
      <Input accept=".jpg" id="contained-button-file" type="file" hidden onChange={handleFiles} />
      <Button style={{ backgroundColor: '#F15F37' }} variant="contained" component="span">
        {file && file !== null ? ' IMAGEN SUBIDA' : 'Subir Imagen'}
      </Button>
      <Typography mt={1} ml={1} style={{ fontWeight: 'bold', color: 'black', fontFamily: 'Bitter', fontSize: '15px' }}>
        {file ? `Peso ${(file.size / 1000000).toFixed(2)} MB` : ''}
      </Typography>
      <Typography mt={1} ml={1} style={{ fontWeight: 'bold', color: 'red', fontFamily: 'Bitter', fontSize: '15px' }}>
        {error}
      </Typography>
    </label>
  )
}

export default UpdateFile
