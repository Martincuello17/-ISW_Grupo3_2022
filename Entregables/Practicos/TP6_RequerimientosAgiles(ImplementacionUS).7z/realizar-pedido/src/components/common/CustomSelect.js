import React from 'react'

import InputLabel from '@mui/material/InputLabel';
import MenuItem from '@mui/material/MenuItem';
import FormControl from '@mui/material/FormControl';
import Select from '@mui/material/Select';

const CustomSelect = ({label, value, onChange, fullWidth, name, error}) => {
  
  return (
    <FormControl variant="filled" sx={{minWidth: 120,}} fullWidth ={fullWidth} error={error}>
        <InputLabel id="demo-simple-select-filled-label">{label}</InputLabel>
        <Select
          labelId="demo-simple-select-filled-label"
          id="demo-simple-select-filled"
          value={value}
          onChange={onChange}
          name={name}
        >
          <MenuItem value="">
            <em>Seleccionar</em>
          </MenuItem>
          <MenuItem value={1}>Córdoba</MenuItem>
          <MenuItem value={2}>La Calera</MenuItem>
          <MenuItem value={3}>Villa Allende</MenuItem>
        </Select>
      </FormControl>
  )
}

export default CustomSelect

