import { TextField } from '@mui/material'
import React from 'react'
const Inputs = ({label, defaultValue, helperText, fullWidth, error, value, name, onChange, type, disabled}) => {
  const formatoFecha = (fecha, formato) =>{
    const map = {
        dd: fecha.getDate() < 10 ? `0${fecha.getDate()}` : fecha.getDate(),
        mm: (fecha.getMonth() + 1) < 10 ? `0${fecha.getMonth() + 1}` : fecha.getMonth() + 1,
        yy: fecha.getFullYear().toString().slice(-2),
        yyyy: fecha.getUTCFullYear()
    }

    return formato.replace(/dd|mm|yyyy|yy/gi, matched => map[matched])
  }
   const date = new Date();
   
   const dateNueva = new Date(date.setDate(date.getDate() + 14))
  
  return (
    <TextField
          label={label}
          defaultValue={defaultValue}
          value={value}
          helperText={helperText}
          variant="filled"
          error={error}
          fullWidth={fullWidth}
          name={name}
          onChange={onChange}
          autoComplete={'off'}
          type={type}
          disabled={disabled}
          inputProps={{min:`${formatoFecha(new Date(),'yyyy-mm-dd')}T00:00`, max: `${formatoFecha(dateNueva,'yyyy-mm-dd')}T00:00`}}
          
    />
  )
}

export default Inputs