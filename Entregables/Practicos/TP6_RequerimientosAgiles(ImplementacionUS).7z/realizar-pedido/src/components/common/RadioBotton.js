import { FormControlLabel, Radio } from '@mui/material'
import React from 'react'

const RadioBotton = ({value, name, checked, onChange, label }) => {
  return (
    <div style={{borderRadius:'5px', height:'50px', border:`1px solid ${checked ? '#F15F37': '#707070'}`}}>
      <FormControlLabel 
        name={name}
        control={<Radio 
          value={value} 
          name={name} 
          checked={checked} 
          onChange={onChange}
          sx={{
          '&.Mui-checked': {
            color: '#F15F37',
          },
          }}/>} 
        label={<div style={{ fontSize: '14px', fontWeight:'bold' }}>{label}</div>}
        style={{marginLeft:'2%', marginTop:'1.2%'}} />
    </div>
  )
}

export default RadioBotton