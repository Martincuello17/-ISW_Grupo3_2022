import React from 'react'
import { useNavigate } from "react-router-dom";
//Materia - UI
import AppBar from '@mui/material/AppBar';
import Box from '@mui/material/Box';
import Toolbar from '@mui/material/Toolbar';
import IconButton from '@mui/material/IconButton';
import Typography from '@mui/material/Typography';
import Menu from '@mui/material/Menu';
import Container from '@mui/material/Container';
import Avatar from '@mui/material/Avatar';
import Tooltip from '@mui/material/Tooltip';
import MenuItem from '@mui/material/MenuItem';
import ShoppingCartOutlinedIcon from '@mui/icons-material/ShoppingCartOutlined';
//componentes
import imgLogo from '../../../src/assets/header/logo.png'
import imgTitulo from '../../../src/assets/header/titulo.png'
import imgUSer from '../../../src/assets/header/user.png'
import { Button } from '@mui/material';

const Header = ({setInicioSesion, inicioSesion}) => {

  let navigate = useNavigate();
  
  const handleClick = () =>  {
    navigate("/");
  }
  
  const [anchorElUser, setAnchorElUser] = React.useState(null);

  const handleOpenUserMenu = (event) => {
    setAnchorElUser(event.currentTarget);
    console.log(event.currentTarget)
  };

  const handleCloseUserMenu = (e) => {
    console.log(e)
    if(e === 3){
      setInicioSesion(false)
      navigate("/");
    }
    setAnchorElUser(null);
  };
  const iniciarSesion = () =>{
    setInicioSesion(true)
  }
  const cerrarSesion = (e) => {
    console.log(e.currentTarget)
  }
  return (
    <AppBar position="static" style={{borderRadius:'0px 0px 25px 25px', backgroundColor:'#000000'}}>
      <Container maxWidth='100%'>
        <Toolbar>
          <Typography
            onClick={handleClick}
            noWrap
            sx={{flexGrow: 1, cursor:'pointer'}}
          >
            <img alt='logo' src={imgLogo} />
          </Typography>
          
          <Typography
            noWrap
            sx={{ flexGrow: 1,}}
          >
            <img alt={'titulo'} src={imgTitulo} />
          </Typography>
          {!inicioSesion ?
            <Button variant="text" onClick={iniciarSesion} style={{color:'white'}}>Iniciar Sesion</Button>
            :
            <>
              <IconButton  size='large' color='inherit' aria-label="shopping cart">
                <ShoppingCartOutlinedIcon fontSize='inherit'/>
              </IconButton>
              <Box >
                <Tooltip title="Mi cuenta">
                  <IconButton onClick={handleOpenUserMenu}>
                    <Avatar alt="AA" src={imgUSer} />
                  </IconButton>
                </Tooltip>
                <Menu
                  onChange={cerrarSesion}
                  sx={{ mt: '45px' }}
                  id="menu-appbar"
                  anchorEl={anchorElUser}
                  anchorOrigin={{
                    vertical: 'top',
                    horizontal: 'right',
                  }}
                  keepMounted
                  transformOrigin={{
                    vertical: 'top',
                    horizontal: 'right',
                  }}
                  open={Boolean(anchorElUser)}
                  onClose={handleCloseUserMenu}
                >
                  <>
                    <MenuItem onClick={() => handleCloseUserMenu(1)}>
                      <Typography textAlign="center">Perfil</Typography>
                    </MenuItem>
                    <MenuItem  onClick={() => handleCloseUserMenu(2)}>
                      <Typography textAlign="center">Mis Pedidos</Typography>
                    </MenuItem>
                    <MenuItem onClick={() => handleCloseUserMenu(3)}>
                      <Typography textAlign="center">Cerrar Sesion</Typography>
                    </MenuItem>
                  </>
                </Menu>
              </Box>
              <Typography
                sx={{ml:2, fontSize:'15px'}}
                noWrap
              >
                Alexis
              </Typography>
            </>
          }
        </Toolbar>
      </Container>
    </AppBar>
  )
}

export default Header