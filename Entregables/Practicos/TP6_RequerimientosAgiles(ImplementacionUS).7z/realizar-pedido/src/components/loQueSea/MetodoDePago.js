import React, { useState } from 'react';

import { Grid, Typography } from '@mui/material'
import CustomButtom from '../common/CustomButtom';
import { useNavigate } from 'react-router-dom';
import RadioBotton from '../common/RadioBotton';
import Inputs from '../common/Inputs';

const MetodoDePago = ({setActiveStep, setDataPedido, dataPedido, activeStep}) => {
  let navigate = useNavigate();

  const [inputs, setInputs] = useState([
    {
      error:false,
      value: dataPedido && dataPedido.tipoPago ? dataPedido.tipoPago : 'efectivo',
      requerido:true,
      name:'tipoPago'
    },
    {
      error:false,
      value:dataPedido && dataPedido.montoEfectivo ? dataPedido.montoEfectivo  : '',
      requerido:true,
      name:'montoEfectivo'
    },
    {
       error:false,
       value: dataPedido && dataPedido.nroTarjeta ? dataPedido.nroTarjeta : '',
       requerido:true,
       name: 'nroTarjeta',
       descripcionError:' '
     },
     {
       error:false,
       value: dataPedido && dataPedido.vencimiento ? dataPedido.vencimiento: '',
       requerido:true,
       name:'vencimiento',
       descripcionError:' '
     },
     {
       error:false,
       value: dataPedido && dataPedido.cvv ? dataPedido.cvv : '',
       requerido:true,
       name:'cvv',
       descripcionError:' '
     },
     {
       error:false,
       value: dataPedido && dataPedido.nombreTitular ? dataPedido.nombreTitular : '',
       requerido:true,
       name:'nombreTitular'
     },
  ])

  const handleCancelar = () => {
    navigate('/')
    setDataPedido(null)
  }

  const onChangeInputs = (e) =>{
    const dataActualizada =  inputs.map(data =>{
      if(data.name === [e.target.name].toString()){
        return {...data, error: false, descripcionError:' ', value:e.target.value}
      }else{
        return data
      }
    })
    setInputs(dataActualizada)
  }

  const validarTarjeta = () => {
    let valido = true
    const datosValidados = inputs.map(data => {
      if(inputs[0].value === 'efectivo' && data.name==='montoEfectivo' && data.value === ''){
        valido = false
        return {...data, error:true}}
      else if(inputs[0].value === 'efectivo' && data.name==='montoEfectivo' && data.value !== '' && parseInt(dataPedido.totalPagar) > parseInt(inputs[1].value)){
        valido = false
        return {...data, error:true, descripcionError:`El monto es inferior a $${dataPedido.totalPagar}`}
      }else if(inputs[0].value === 'tarjeta' && data.name==='vencimiento' && ((data.value ==='' || !validateVencimiento(data.value)) || validateVencimiento(data.value) === 1)){
        valido = false
        if(validateVencimiento(data.value) === 1) {
          return {...data, error:true, descripcionError:'Tarjeta Vencida'}
        }
        else {
        return {...data, error:true, descripcionError:'formato MM/YYYY'}
      }
      }else if(inputs[0].value === 'tarjeta' && data.name==='nroTarjeta' && (data.value ==='' ||( validateTarjeta(data.value) === 1 || validateTarjeta(data.value) ===  2))){
        valido = false
        if(validateTarjeta(data.value) === 1 ){
          valido = false
          return {...data, error:true, descripcionError:'No es una tarjeta VISA o MasterCard'}
        }else{
          valido = false
          return {...data, error:true, descripcionError:'ingrese 16 digitos'}
        }
      }else if(inputs[0].value === 'tarjeta' && data.name==='cvv' && (data.value ==='' || !validateCVV(data.value))){
        valido = false
        return {...data, error:true, descripcionError:'ingrese 3 o 4 digitos'}
      }else if(inputs[0].value === 'tarjeta' && data.name==='nombreTitular' && data.value ==='' ){
        valido = false
        return {...data, error:true, descripcionError:' '}
      }else{
        return data
      }
    })
    if(valido === false){
      setInputs(datosValidados)
    }
    return valido
  }

  function validateVencimiento(cadena) {
    const fecha = new RegExp("(((0[123456789]|10|11|12)/(([1][9][0-9][0-9])|([2][0-9][0-9][0-9]))))");
    const number = new RegExp('^.{7}$');
    if (fecha.test(cadena) && number.test(cadena))
    {
      const month = cadena.substring(0,2);
      const year = cadena.substring(3, 7);
      console.log(month)
      console.log(year)
      if (year.localeCompare('2022') == -1 || (year.localeCompare('2022') == 0 && month.localeCompare('08') == -1)) 
        return 1;
      else
        return true;
      }
    else
        return false;
  }
  
  function validateCVV(cadena) {
    var reg = new RegExp("^[0-9]{3,4}$");
    if (reg.test(parseInt(cadena))){
      return true;
    }
    else{
      return false;
    }
    
  }
  function validateTarjeta(cadena) {
    const number = new RegExp("^[0-9]{16}$");
    if (!number.test(parseInt(cadena))){
      return 2;
    }else if(!cadena.match(/^(?:4[0-9]{12}(?:[0-9]{3})?|5[1-5][0-9]{14})$/)){
      return 1
    }else{
      return false
    }
    
  }

  const handleAceptar = () => {
    if(validarTarjeta()){
      setDataPedido({
        ...dataPedido,
        pantalla: activeStep,
        tipoPago:inputs[0].value,
        montoEfectivo:inputs[1].value,
        nroTarjeta:inputs[2].value,
        vencimiento:inputs[3].value,
        cvv:inputs[4].value,
        nombreTitular:inputs[5].value,
      })
      setActiveStep(data => data +1) 
    }
  }
  return (
    <Grid container mt={0} alignItems='center' justifyItems={'center'} justifyContent='center' direction="row" columnSpacing={1} rowSpacing={0}>
            <Grid item xs={3}>
              
            </Grid>
            <Grid item xs={9} mb={1} mt={1}>
              <Typography  style={{fontWeight:'bold', fontFamily:'Bitter', fontSize:'28px'}}>
              ¿Cómo vas a pagar?
              </Typography>
            </Grid>
            <Grid item xs={3} >
              
            </Grid>
            <Grid item xs={6} mb={1}>
                <RadioBotton 
                  value={'efectivo'} 
                  checked={inputs[0].value === 'efectivo'}
                  onChange={onChangeInputs}
                  name={'tipoPago'}
                  label={'Efectivo'}
                />
            </Grid>
            <Grid item xs={3} >
              
            </Grid>
            {inputs[0].value === 'efectivo' ?
              <>
                <Grid item xs={3} >
                  
                </Grid>
                <Grid item xs={6} mb={3}>
                    <Inputs
                      name={'montoEfectivo'}
                      defaultValue={inputs[1].value}
                      value={inputs[1].value}
                      error={inputs[1].error} 
                      label={'¿Con cuanto vas a pagar?*'}
                      fullWidth={true}
                      helperText={inputs[1].descripcionError}
                      onChange={onChangeInputs}
                      type={'number'} 
                    />
                    {
                      !inputs[1].error ?
                        <span style={{fontSize:'0.8rem', paddingLeft:'10px'}}>monto a pagar ${dataPedido.totalPagar}</span>
                      : null
                    }
                </Grid>
                <Grid item xs={3}>
                </Grid>
              </>: null
            }
            <Grid item xs={3} >
              
            </Grid>
            <Grid item xs={6} mb={2}>
                <RadioBotton 
                  value={'tarjeta'} 
                  checked={inputs[0].value === 'tarjeta'}
                  onChange={onChangeInputs}
                  name={'tipoPago'}
                  label={'Tarjeta de crédito o débito'}
                />
            </Grid>
            <Grid item xs={3}>
            </Grid>
            {inputs[0].value === 'tarjeta' ?
            <>
              <Grid item xs={3} >
              </Grid>
              <Grid item xs={6} >
                <Inputs
                      name={'nroTarjeta'}
                      defaultValue={inputs[2].value}
                      value={inputs[2].value}
                      error={inputs[2].error} 
                      label={'Número de tarjeta*'}
                      fullWidth={true}
                      helperText={inputs[2].descripcionError}
                      onChange={onChangeInputs}
                      type={'number'}
                      maxLength={16} 
                  />
              </Grid>
              <Grid item xs={3}>
              </Grid> 
              <Grid item xs={3} >
              </Grid>
              <Grid item xs={3} >
                <Inputs
                      name={'vencimiento'}
                      defaultValue={inputs[3].value}
                      value={inputs[3].value}
                      error={inputs[3].error} 
                      label={'Vencimiento*'}
                      fullWidth={true}
                      helperText={inputs[3].descripcionError}
                      onChange={onChangeInputs}
                      //type={'number'} 
                  />
              </Grid>
              <Grid item xs={3} >
                <Inputs
                      name={'cvv'}
                      defaultValue={inputs[4].value}
                      value={inputs[4].value}
                      error={inputs[4].error} 
                      label={'CVV*'}
                      fullWidth={true}
                      helperText={inputs[4].descripcionError}
                      onChange={onChangeInputs}
                      type={'number'} 
                  />
              </Grid>
              <Grid item xs={3}>
              </Grid>
              <Grid item xs={3} >
              </Grid>
              <Grid item xs={6} mb={3}>
                <Inputs
                      name={'nombreTitular'}
                      defaultValue={inputs[5].value}
                      value={inputs[5].value}
                      error={inputs[5].error} 
                      label={'Nombre del titular*'}
                      fullWidth={true}
                      //helperText={'*Requerido'}
                      onChange={onChangeInputs}
                  />
              </Grid>
              <Grid item xs={3}>
              </Grid>  
            </>: null
            }
            <Grid item xs={3}>
            </Grid>
            <Grid item xs={3} >
                <CustomButtom 
                  label={'Cancelar'} 
                  variant={'contained'} 
                  style={{backgroundColor: '#fff', color:'grey', borderRadius:'20px', border:'1px solid #CBCBCB', width:'110px', marginLeft:'100px'}}
                  onClick={handleCancelar}
                  />
              </Grid>
            <Grid item xs={5} >
              <CustomButtom 
                label={'Siguiente'} 
                variant={'contained'} 
                style={{backgroundColor: '#F15F37', borderRadius:'20px', width:'115px', marginLeft:'50px'}} 
                onClick={handleAceptar}/>
            </Grid>
              
            <Grid item xs={1}>
            
            </Grid>
      </Grid>
  )

}

export default MetodoDePago